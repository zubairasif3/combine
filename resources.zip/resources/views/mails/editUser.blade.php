<h4>Welcome to PM247</h4>
<p>Below are your new credentials</p>
<p>
    <strong>Login Url: {{url('/')}}</strong><br/>
    <strong>Email: </strong> {{$data["email"]}}<br/>
    <strong>Password: </strong> {{$data["password"]}}<br/>
</p>
