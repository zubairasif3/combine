<b>Dear {{$payment->job->engineer_user->name ?? ""}}</b>
<br>
<br>
<div>
    The Payment has been received for the Job at “{{$payment->job->postcode}}”. Please only proceed when
the contract has also been confirmed as received. You will be informed once the
contract is received by email and sms.

</div>
<br>
<b>Kind Regards</b>
<br><br>
<b>Contracts & Payments Team</b>