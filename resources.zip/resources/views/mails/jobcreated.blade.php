
<b>Dear PM247 Team,</b>

<p>A request has been made for a Agent Assigned to be sent for the following details.</p>

<div>
    Request Made By: <b>“{{$job->added_by_user_name()}}”</b> <br>
    Job creation Time: <b>“{{$job->created_at}}”</b> <br>
    Customer Email: <b>“{{$job->customer_email}}”</b> <br>
    Postcode: <b>“{{$job->postcode}}”</b> <br>
    Job Invoice Number: <b>“{{$job->job_invoice_no}}”</b> <br>
</div>
<br>
<b>Kind Regards</b>
<br><br>
<b>Agent Assigned  Team</b>