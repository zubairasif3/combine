<h4>Welcome to PM247</h4>
<p>Below are your login credentials</p>
<p>
    <strong>Login Url: {{url('/')}}</strong><br/>
    <strong>Email: </strong> {{$data["email"]}}<br/>
    <strong>Password: </strong> {{$data["password"]}}<br/>
</p>
