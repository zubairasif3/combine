<b>Dear {{$contract->job->engineer_user->name ?? ""}}</b>
<br>
<br>
<div>
    The contract has been signed for the Job at “{{$contract->job->postcode}}”. Please only proceed when payment has also been confirmed as paid. You will be informed once payment is received by email and sms.
</div>
<br>
<b>Kind Regards</b>
<br><br>
<b>Contracts & Payments Team</b>